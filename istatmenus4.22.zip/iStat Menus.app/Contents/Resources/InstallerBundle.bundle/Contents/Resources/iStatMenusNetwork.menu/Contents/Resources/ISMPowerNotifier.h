//
//  ISMPowerNotifier.h
//  iStatMenusTemps
//
//  Created by Bjango on 3/22/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#include <IOKit/IOKitLib.h>
#include <IOKit/ps/IOPSKeys.h>
#include <IOKit/ps/IOPowerSources.h>
#include <IOKit/pwr_mgt/IOPMLib.h>
#include <IOKit/IOMessage.h>

#define PowerStateUnknown -1
#define PowerStateBattery 0
#define PowerStateCharging 1
#define PowerStateCharged 2

@interface ISMPowerManager : NSObject {
    int _source;
	io_connect_t rootPort;
	io_object_t notifier;
	IONotificationPortRef notificationPort;
	CFRunLoopSourceRef powerNotifierRunLoopSource;
}

@property (nonatomic) int source;

+ (ISMPowerManager *)sharedPowerManager;

@end
